from mg_app_framework.db.mongo_operate import MongoLogOperator
from mg_app_framework.db.operator import LogOperatorFactory

