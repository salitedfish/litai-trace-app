from enum import Enum
from typing import Optional

from asyncio import get_event_loop, ensure_future
from mg_app_framework.components import TaskKey
from mg_app_framework.config import get_organization
from mg_app_framework.db.mongo_operate import MongoLogOperator


class LogOperatorFactory(object):
    operator_mapper = {}

    @staticmethod
    def init_operator(operator_type: Enum) -> Optional[MongoLogOperator]:
        if operator_type == TaskKey.idi_server:
            if LogOperatorFactory.operator_mapper.get(operator_type) is None:
                mongo_operator = MongoLogOperator(get_organization())
                create_index = mongo_operator.ensuer_indexes()
                loop = get_event_loop()
                task = loop.create_task(create_index)
                ensure_future(task)
                LogOperatorFactory.operator_mapper.update({operator_type: mongo_operator})
            return LogOperatorFactory.operator_mapper.get(operator_type)
        else:
            return None
