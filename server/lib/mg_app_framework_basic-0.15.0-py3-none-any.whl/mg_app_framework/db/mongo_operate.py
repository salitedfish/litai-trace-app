#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date : 2022-02-22

from mg_app_framework.components import TaskKey
from mg_app_framework.config import get_handler,get_organization, get_logger
from typing import Any
import traceback
from time import time
from functools import wraps
from asyncio import Lock, iscoroutinefunction, CancelledError


def raise_exception(f):
    @wraps(f)
    def running_fun(*args, **kwargs):
        try:
            result = f(*args, **kwargs)
        except Exception as e:
            get_logger().error('Error occured in {} cause {}'.format(f.__name__, str(e)))
            traceback.print_exc()
        else:
            return result

    @wraps(f)
    async def running_async_fun(*args, **kwargs):
        try:
            result = await f(*args, **kwargs)
        except CancelledError:
            get_logger().error('CancelledError occured in {}'.format(f.__name__))
            raise
        except Exception as e:
            get_logger().error('Error occured in {} cause {}'.format(f.__name__, str(e)))
            traceback.print_exc()
        else:
            return result

    return running_async_fun if iscoroutinefunction(f) else running_fun


class OperatorBase(object):
    def __init__(self, db: str, collection: str):
        self.db = db
        self.collection = collection
        self._operator = None

    @property
    def operator(self):
        return self._operator

    @operator.setter
    def operator(self, collection_operator: Any):
        self._operator = collection_operator

    # @raise_exception
    async def insert_record(self, record: dict, operator=None) -> bool:
        if not operator:
            operator = self.operator
        await operator.insert_one(record)
        return True

    @raise_exception
    async def insert_many(self, records: list, operator=None) -> bool:
        if not operator:
            operator = self.operator
        await operator.insert_many(records)
        return True

    @raise_exception
    async def delete_many(self, query_filter, operator=None) -> bool:
        if not operator:
            operator = self.operator
        await operator.delete_many(query_filter)
        return True

    @raise_exception
    async def delete_one(self, query_filter, operator=None) -> bool:
        if not operator:
            operator = self.operator
        await operator.delete_one(query_filter)
        return True

    @raise_exception
    async def update_one_record(self, query_filter: dict, update_info: dict, operator=None, is_insert=True):
        if not operator:
            operator = self.operator
        await operator.find_one_and_update(query_filter, {'$set': update_info}, upsert=is_insert)

    @raise_exception
    async def get_one_record_by_filter(self, query_filter: dict, operator=None, **kwargs):
        if not operator:
            operator = self.operator
        projection = kwargs.get('projection', {'_id': 0})
        sort = kwargs.get('sort', None)
        record = await operator.find_one(query_filter, projection=projection, sort=sort)
        return record or None

    @raise_exception
    async def get_list_record_by_filter(self, query_filter: dict, operator=None, **kwargs) -> list:
        if not operator:
            operator = self.operator
        projection = kwargs.get('projection', {'_id': 0})
        sort = kwargs.get('sort', None)
        skip = kwargs.get('skip')
        limit = kwargs.get('limit')
        all_records = []
        if skip or limit:
            async for document in operator.find(query_filter, projection=projection, sort=sort).skip(skip).limit(limit):
                all_records.append(document)
        else:
            async for document in operator.find(query_filter, projection=projection, sort=sort):
                all_records.append(document)
        return all_records

    @raise_exception
    async def get_record_by_aggregate_pipeline(self, aggregate_pipeline, operator=None):
        if not operator:
            operator = self.operator
        response = []
        async for doc in operator.aggregate(aggregate_pipeline):
            response.append(doc)
        return response

    @raise_exception
    async def distinct(self, field: str, query_filter: dict = None, operator: object = None):
        if not operator:
            operator = self.operator
        result = await operator.distinct(field, filter=query_filter)
        return result

    @raise_exception
    async def count(self, query_filter: dict, operator: object = None) -> int:
        if not operator:
            operator = self.operator
        current_of_filter = await operator.count_documents(query_filter)
        return current_of_filter


class MongoLogOperator(OperatorBase):

    def __init__(self, db: str, collection: str = 'operate_log'):
        super(MongoLogOperator, self).__init__(db, collection=collection)
        mongo_handler = get_handler(TaskKey.idi_server)
        target_db = mongo_handler['manugence_root']
        self.operator = target_db[collection]

    @raise_exception
    async def ensuer_indexes(self):
        # 创建索引的函数
        await self.operator.create_index([('user', 1)], background=True)
        await self.operator.create_index([('method', 1)], background=True)
