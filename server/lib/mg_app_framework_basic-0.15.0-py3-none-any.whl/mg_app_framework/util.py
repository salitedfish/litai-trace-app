import json
import traceback
import time
from mg_app_framework.client import HttpClient
from mg_app_framework.config import Store, get_uuid, get_logger, get_context, get_organization
from mg_app_framework.message import MesCode
from mg_app_framework.db.operator import LogOperatorFactory
from mg_app_framework.components import TaskKey
from functools import wraps


async def identify_check(identify_info: dict) -> bool:
    try:
        verification_url = f'{Store.get_login_url()}/api/auth/3rd/verify/personnel/pwd'
        user_name = identify_info.get('user_name')
        identify_info.update({
            'work_id': user_name,
            'organization': get_organization(),
        })
        request_url = verification_url
        if request_url:
            client = HttpClient()
            response = await client.post(url=request_url, data={"user_list": [identify_info]})
            data = response.data
            client.close()
            return data.get(user_name, False)
    except Exception as e:
        get_logger().exception(e)
        raise e


async def identify_check_with_face(identify_info: str) -> dict:
    try:
        verification_face_url = f'{Store.get_login_url()}/api/auth/personnel/face_recog'
        request_url = verification_face_url
        if request_url:
            client = HttpClient()
            response = await client.post(url=request_url,
                                         data={"user_pic": identify_info, 'organization': get_organization()})
            data = response.data
            client.close()
            if not data:
                raise Exception(response.info)
            else:
                get_logger().debug(data)
                return data
    except Exception as e:
        get_logger().exception(e)
        raise e


async def identify_check_with_option(check_type, identify_info):
    if check_type == 'password':
        verify_result = await identify_check(identify_info)
        if verify_result:
            return identify_info.get('user_name')
    elif check_type == 'image':
        verify_result = await identify_check_with_face(identify_info)
        if verify_result:
            return verify_result.get('work_id')
    else:
        raise Exception('提供的校验方式有误，请核实')


async def is_user_has_authority(self, user_name: str, appid: str, url_path: str):
    user_auth_url = f'{Store.get_login_url()}/api/auth/validate_url_for_user'
    func_name_url_note_map = get_context('func_name_url_note_map')
    url_note = func_name_url_note_map.get(url_path)
    if not url_note:
        # url转note 使用lib中request url映射
        url_patterns = self.application.wildcard_router.rules
        for url_pattern in url_patterns:
            target_pattern = url_pattern.matcher.match(self.request)
            if target_pattern is not None:
                url_path = url_pattern.matcher.regex.pattern.rstrip('$')
                url_note = func_name_url_note_map.get(url_path)
                break
    request_body = {
        'organization': get_organization(),
        'user_name': user_name,
        'appid': appid,
        'url_path': url_path,
        'url_note': url_note
    }
    try:
        request_url = user_auth_url
        if request_url:
            client = HttpClient()
            response = await client.post(url=request_url,
                                         data=request_body)
            client.close()
            return response.code == MesCode.success
    except Exception as e:
        get_logger().exception(e)
        raise e


# 用户校验和人脸校验装饰器
def rolerequired(method):
    # 使用此装饰器需要再提供一个字段包含当前用户的校验信息: authority_info:{check_type, identify_info}
    async def wrapper(self, *args, **kwargs):
        if self.data:
            body_data = self.data
            if 'authority_info' in body_data:
                authority_info = body_data.get("authority_info")
                current_user = await identify_check_with_option(authority_info.get('check_type'),
                                                                authority_info.get('identify_info'))
                if current_user:
                    has_authority = await is_user_has_authority(self, current_user, get_uuid(), self.request.path)
                    if has_authority:
                        # 如果用户有权限访问此接口，在self中增加字段operator
                        self.operator = current_user
                        return await method(self, *args, **kwargs)
                    else:
                        result = {
                            "code": MesCode.fail,
                            "data": self.data,
                            "info": "当前用户没有权限访问此接口"
                        }
                        self.finish(json.dumps(result, ensure_ascii=False))
                        return
        result = {
            "code": "auth",
            "data": self.data,
            "info": "用户信息有误"
        }
        self.finish(json.dumps(result, ensure_ascii=False))
        return

    return wrapper


# 登录以及权限检查装饰器
def loginrequired(method):
    async def wrapper(self, *args, **kwargs):
        if Store.context['debug_flag']:
            return await method(self, *args, **kwargs)
        login_switch = Store.store.get_login_switch()
        if not login_switch:
            return await method(self, *args, **kwargs)
        else:
            result = {}
            result['app_group'] = Store.get_app_group()
            result['app_name'] = Store.get_app_name()
            login_url = Store.get_login_url()

            # 检查app_uuid
            app_uuid = get_uuid()
            if not app_uuid:
                result["code"] = MesCode.fail
                result["data"] = None
                result["info"] = '无法获取appid'
                return self.finish(json.dumps(result, ensure_ascii=False))

            # 获取登录参数
            login_uuid = self.get_cookie('login_uuid')
            union_id = None
            func_name_url_note_map = get_context('func_name_url_note_map')
            url = self.request.uri
            func_name = self.__class__.__name__
            url_note = func_name_url_note_map.get(url)
            if not url_note:
                url_patterns = self.application.wildcard_router.rules  #
                for url_pattern in url_patterns:
                    target_pattern = url_pattern.matcher.match(self.request)
                    if target_pattern is not None:
                        url = url_pattern.matcher.regex.pattern.rstrip('$')
                        url_note = func_name_url_note_map.get(url)
                        break

            if not login_uuid:
                # 如果cookie中未获取到login_uuid, 尝试从request body中获取
                # 这里用于app间发送数据, 框架包装的client封装中包含了请求方登录信息
                if self.request.body:
                    try:
                        body_data = json.loads(self.request.body.decode('utf-8'))
                        if 'manugence_login_uuid' in body_data:
                            login_uuid = body_data['manugence_login_uuid']
                    except UnicodeDecodeError as e:
                        get_logger().error(f'decode error: {e}')
                    except json.JSONDecodeError as e:
                        get_logger().error(f'json.loads error: {e}')
                if 'unionid' in self.request.headers:
                    union_id = self.request.headers['unionid']

            if login_uuid:
                post_data = {'login_uuid': str(login_uuid),
                             'app_uuid': str(app_uuid),
                             'func_name': func_name,
                             'url_note': url_note,
                             'url': url}

            elif union_id:
                # 处理微信小程序的认证问题，微信小程序只有unionid, 无法设置cookie
                post_data = {'unionid': str(union_id),
                             'app_uuid': str(app_uuid),
                             'func_name': func_name,
                             'url_note': url_note,
                             'url': url}
            else:
                # 没有登录过
                result["code"] = MesCode.login
                result["data"] = {'login_url': login_url, 'app_id': app_uuid}
                result["info"] = '登录超时，请重新登录'
                return self.finish(json.dumps(result, ensure_ascii=False))

            # 发起登录请求
            client = HttpClient()
            login_role_check_url = login_url + '/api/auth/check_login_role'
            res = await client.post(login_role_check_url, data=post_data)
            res_code = res.code
            res_mes = res.info

            # 执行被装饰的请求
            if res_code == MesCode.success:
                return await method(self, *args, **kwargs)
            else:
                result["code"] = res_code
                result["info"] = res_mes
                result["data"] = None
                if res_code == MesCode.login:  # 登录过期
                    result["data"] = {'login_url': login_url, 'app_id': app_uuid}

                return self.finish(json.dumps(result, ensure_ascii=False))

    return wrapper


def log_request(func):
    @wraps(func)
    async def wrapper(self, *args, **kwargs):
        if not Store.store.is_log_enable():
            return await func(self, *args, **kwargs)

        login_name = self.get_cookie('login_name', '')
        organization = get_organization()
        # 获取请求信息
        request_method = self.request.method
        request_path = self.request.path
        request_query = self.request.query
        try:
            request_body = self.request.body.decode('utf-8') if self.request.body else None
        except UnicodeDecodeError as e:
            get_logger().error(f'decode error: {e}')
            request_body = {}
        request_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        source_ip = self.request.remote_ip
        user_agent = self.request.headers.get('User-Agent', 'Unknown')
        # date = time.strftime("%Y-%m-%d", time.localtime())
        app_name = Store.get_app_name()
        app_moudule_name = Store.get_app_module_name()
        url_patterns = self.application.wildcard_router.rules
        func_name_url_note_map = get_context('func_name_url_note_map')
        func_name = ''
        for url_pattern in url_patterns:
            target_pattern = url_pattern.matcher.match(self.request)
            if target_pattern is not None:
                url = url_pattern.matcher.regex.pattern.rstrip('$')
                func_name = func_name_url_note_map.get(url)
                break

        # 记录请求信息
        log_data = {
            'user': login_name,
            'organization': organization,
            'method': request_method,
            'path': request_path,
            'query': request_query,
            'body': request_body,
            'app_name': app_name,
            'app_module_name': app_moudule_name,
            'func_name': func_name,
            'time': request_time,
            'source_ip': source_ip,
            'user_agent': user_agent,
        }

        # 存储到数据库
        try:
            log_operator = LogOperatorFactory.init_operator(TaskKey.idi_server)
            await log_operator.insert_record(log_data)

        except Exception as e:
            get_logger().exception(e)

        # 调用原方法
        return await func(self, *args, **kwargs)

    return wrapper


# 小数点格式转换接口
def decimal_format(num, digit=None):
    if digit is None:
        if isinstance(num, list):
            result = []
            for i in num:
                i = float(i)
                if i < 1:
                    i_result = '%.4f' % i
                elif 1 <= i < 1000:
                    i_result = '%.2f' % i
                else:
                    i_result = str(int(i))
                result.append(i_result)
        else:
            num = float(num)
            if num < 1:
                result = '%.4f' % num
            elif 1 <= num < 1000:
                result = '%.2f' % num
            else:
                result = str(int(num))
    else:
        if digit > 0:
            rule = '%.' + str(digit) + 'f'
            if isinstance(num, list):
                result = []
                for i in num:
                    i_result = rule % i
                    result.append(i_result)
            else:
                result = rule % num
        else:
            if isinstance(num, list):
                result = []
                for i in num:
                    i_result = str(int(i))
                    result.append(i_result)
            else:
                result = str(int(num))
    return result


# 主数据时间格式转换为cron定时格式
def cron_format(cron_unit):
    return_cron_format = {
        "year": "*",
        "month": "*",
        "day": "*",
        "day_of_week": "*",
        "hour": "*",
        "minute": "*",
        "second": "*",
    }
    if cron_unit == '小时':
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '两小时':
        return_cron_format['hour'] = '0,2,4,6,8,10,12,14,16,18,20,22'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '四小时':
        return_cron_format['hour'] = '0,4,8,12,16,20'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '八小时':
        return_cron_format['hour'] = '0,8,16'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '半天':
        return_cron_format['hour'] = '0,12'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '天':
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '周':
        return_cron_format['day_of_week'] = '0'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '月':
        return_cron_format['day'] = '1'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '年':
        return_cron_format['month'] = '1'
        return_cron_format['day'] = '1'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '分钟':
        return_cron_format['second'] = '0'
    elif cron_unit == '白班':
        return_cron_format['hour'] = '8,16'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'

    return return_cron_format


def log_exception(e, err_info=''):
    """
    记录代码执行异常信息包括traceback
    :param e: 异常exception
    :param err_info: 可选填的错误信息
    """
    traceback_str = ''.join(traceback.format_tb(e.__traceback__))
    if err_info:
        err_msg = '{}, 异常信息: {}\n'.format(err_info, str(e))
    else:
        err_msg = '异常信息: {}\n'.format(str(e))
    get_logger().error(err_msg)
    get_logger().error('\n')
    get_logger().error('traceback信息: {0}'.format(traceback_str))
