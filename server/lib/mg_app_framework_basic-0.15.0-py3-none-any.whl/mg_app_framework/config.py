import os
import logging
from os import getpid
from os.path import basename, splitext, join, exists
from logging.handlers import RotatingFileHandler
from abc import ABCMeta, abstractmethod
from inspect import iscoroutinefunction
from pathlib import Path
from mg_app_framework.components import TaskKey


class AppType:
    cron = 'cron'
    interval = 'interval'
    service = 'service'
    user = 'user'
    date = 'date'
    module = 'module'
    portal = 'portal'


class AppPort:
    manager = 80
    sds = 8088


class AppHaRole:
    master = 'master'
    follower = 'follower'


block_ports = [1, 7, 9, 11, 13, 15, 17, 19, 20, 21, 22, 23, 25, 37, 42, 43, 53, 77, 79, 87, 95, 101, 102, 103, 104, 109,
               110, 111, 113, 115, 117, 119, 123, 135, 139, 143, 179, 389, 465, 512, 513, 514, 515, 526, 530, 531, 532,
               540, 556, 563, 587, 601, 636, 993, 995, 2049, 4045, 6000, 6665, 6666, 6667, 6668, 6669]


class LogLevel:
    DEBUG = 'DEBUG'
    INFO = 'INFO'
    WARN = 'WARN'
    ERROR = 'ERROR'


class UserRole:
    super_admin = 'super_admin'
    admin = 'admin'
    public = 'public'


class UserOrganization:
    ALL = 'ALL'


class AppPortError(Exception):
    pass


class FuncTypeError(Exception):
    pass


class InitTaskError(Exception):
    pass


class LackUuidError(Exception):
    pass


async def do_nothing():
    pass


def _get_urls_file(path, app_urls, module_url):
    try:
        for filename in os.listdir(path):
            full_path = os.path.join(path, filename)
            if os.path.isdir(full_path):
                _get_urls_file(full_path, app_urls, module_url)
            elif filename == 'urls.py':
                urls = getattr(
                    __import__((module_url + os.path.join(path.split(module_url)[1], 'urls')).replace(os.sep, '.'),
                               fromlist=['url']), 'url')
                for i in urls:
                    tmp_dic = {
                        'url': i[0],
                        'func': i[1].__name__,
                        'note': i[2] if len(i) >= 3 else ''  # 兼容没有url注释的情况
                    }
                    app_urls.append(tmp_dic)
    except Exception as e:
        get_logger().exception(e)


class DefaultLogger:
    logger = None

    @classmethod
    def get_logger(cls, log_path, log_size, log_num):
        if not cls.logger:
            cls.logger = logging.getLogger(splitext(basename(log_path))[0])
            cls.logger.setLevel(logging.INFO)
            app_uuid = get_uuid()
            formatter = logging.Formatter('%(asctime)s ' + '%s' % app_uuid +
                                          ' %(name)s %(levelname)s %(pathname)s %(funcName)s %(lineno)d : %(message)s')

            steam_handler = logging.StreamHandler()
            steam_handler.setFormatter(formatter)
            cls.logger.addHandler(steam_handler)

            if log_path:
                rotate_handler = RotatingFileHandler(log_path, maxBytes=log_size, backupCount=log_num)
                rotate_handler.setFormatter(formatter)
                cls.logger.addHandler(rotate_handler)

        return cls.logger


class AppConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_module_dir(self):
        pass

    @abstractmethod
    def get_admin_host(self):
        pass

    @abstractmethod
    def get_log_path(self):
        pass

    @abstractmethod
    def get_uuid_path(self):
        pass

    @abstractmethod
    def get_data(self):
        pass

    def get_logger(self):
        return DefaultLogger.get_logger(self.get_log_path(), self.log_size(), self.log_num())

    def get_app_port(self):
        return 80

    def get_app_ip(self):
        return None

    def get_ip(self):
        return None

    def get_login_switch(self):
        return True

    def get_login_url(self):
        return None

    def connect_admin(self):
        return True

    def cross_domain(self):
        return False

    def organization_info(self):
        return None

    def app_icon(self):
        return 'view_module'

    def is_multi_tenant(self):
        return False

    def log_size(self):
        return 1024 * 1024 * 10

    def log_num(self):
        return 30

    def is_log_enable(self):
        return True

    def get_swagger_enable(self):
        return False

    def get_debug_login_name(self):
        return 'admin'


class Store:
    store = None
    context = {
        'init_tasks': {},
        'init_tasks_keys_list': [],
        'tasks': None,
        'handlers': {},
        'loop': None,
        'config_func': do_nothing,
        'data_func': do_nothing,
        'ha_connection': None,
        'ha_other_side_role': None,
        'scheduler': None,
        'debug_flag': False,
        'organization': {}
    }

    # common funcs
    @staticmethod
    def get_pid():
        return getpid()

    # store fields
    @classmethod
    def set_loop(cls, new_loop):
        update_context('loop', new_loop)

    @classmethod
    def get_loop(cls):
        return get_context('loop')

    @classmethod
    def set_tasks(cls, new_tasks):
        update_context('tasks', new_tasks)

    @classmethod
    def get_tasks(cls):
        return get_context('tasks')

    @classmethod
    def get_config_func(cls):
        return get_context('config_func')

    @classmethod
    def get_data_func(cls):
        return get_context('data_func')

    @classmethod
    def get_init_task_keys(cls):
        return get_context('init_tasks_keys_list')

    @classmethod
    def get_init_task_config(cls, key):
        if key in get_context('init_tasks'):
            return get_context('init_tasks')[key]
        else:
            return None

    @classmethod
    def get_module_dir(cls):
        return cls.store.get_module_dir()

    @classmethod
    def get_websocket_url(cls):
        return 'ws://' + cls.store.get_admin_host() + '/appconn'

    @classmethod
    def get_login_url(cls):
        if cls.store.get_login_url():
            return 'http://' + cls.store.get_login_url()
        else:
            return 'http://' + cls.store.get_admin_host() + ':8765'

    @classmethod
    def get_data(cls, debug=False):
        data = cls.store.get_data()

        # 默认打包部署后运行app时从mg获取老配置, 开发模式覆盖老配置
        if not debug:
            if 'config_create' not in data:
                data['config_create'] = False
        else:
            if 'config_create' not in data:
                data['config_create'] = True

        pid = {
            'pid': cls.get_pid()
        }
        data.update(pid)

        app_ip = cls.store.get_ip()
        if app_ip:
            ip = {
                'ip': app_ip
            }
            data.update(ip)

        app_port = cls.store.get_app_port()
        if app_port:
            port = {
                'port': app_port
            }
            data.update(port)

        app_ha_role = get_ha_role()
        ha_role = {
            'ha_role': app_ha_role
        }
        data.update(ha_role)

        app_icon = cls.store.app_icon()
        app_icon_info = {
            'app_icon': app_icon
        }
        data.update(app_icon_info)

        if 'log_level' not in data:
            log_level = {
                'log_level': 'INFO'
            }
            data.update(log_level)

        # url
        app_urls = []
        module_dir = Store.get_module_dir()
        handlers_dir = join(module_dir, 'handlers')
        if exists(handlers_dir):
            module_name = basename(module_dir)
            _get_urls_file(handlers_dir, app_urls, os.path.join(module_name, 'handlers'))

        app_urls = {
            'app_urls': app_urls
        }
        data.update(app_urls)
        return data

    @classmethod
    def update_data(cls, data):
        cls.store.data = data

    @classmethod
    def get_switch(cls):
        value = True
        if 'switch' in cls.store.data:
            value = cls.store.data['switch']
        return value

    @classmethod
    def set_switch(cls, new_switch):
        cls.store.data['switch'] = new_switch

    @classmethod
    def get_app_type(cls):
        return cls.store.data['app_type']

    @classmethod
    def get_app_group(cls):
        return cls.store.data['app_group']

    @classmethod
    def get_app_name(cls):
        return cls.store.data['app_name']

    @classmethod
    def get_app_module_name(cls):
        if 'app_module_name' in cls.store.data:
            return cls.store.data['app_module_name']
        return None

    @classmethod
    def get_app_port(cls):
        return cls.store.get_app_port()

    @classmethod
    def get_app_ip(cls):
        return cls.store.get_app_ip()

    @classmethod
    def get_ip(cls):
        return cls.store.get_ip()

    @classmethod
    def set_ha_role(cls, new_role):
        old_role = get_ha_role()
        if old_role is not None:
            cls.store.data['data']['config_data']['ha_settings']['group_member']['ha_role']['value'] = new_role

    @classmethod
    def get_ha_websocket_url(cls):
        try:
            ha_ip = cls.store.data['data']['config_data']['ha_settings']['group_member']['ha_ip']['value']
            ha_port = cls.store.data['data']['config_data']['ha_settings']['group_member']['ha_port'][
                'value']
            ha_websocket_url = 'ws://' + ha_ip + ':' + ha_port + '/ha_connect_url'
        except Exception:
            ha_websocket_url = None
        return ha_websocket_url

    @classmethod
    def set_ha_handler(cls, var):
        get_context('handlers')['ha'] = var

    @classmethod
    def get_ha_handler(cls):
        if 'ha' in get_context('handlers'):
            return get_context('handlers')['ha']
        else:
            return None

    @classmethod
    def get_trigger_args(cls):
        store_data = cls.store.data
        return_data = None
        if 'data' in store_data:
            if 'config_data' in store_data['data']:
                if 'schedule_settings' in store_data['data']['config_data']:
                    if 'group_member' in store_data['data']['config_data']['schedule_settings']:
                        if 'cycle' in store_data['data']['config_data']['schedule_settings']['group_member']:
                            value = int(store_data['data']['config_data']['schedule_settings']['group_member']['cycle'][
                                            'value'])
                            return_data = {
                                'trigger_type': AppType.interval,
                                'value': value
                            }
                        elif 'cron_set' in store_data['data']['config_data']['schedule_settings']['group_member']:
                            year = ','.join(
                                cls.store.data['data']['config_data']['schedule_settings']['group_member']['cron_set'][
                                    'value']['year'])
                            month = ','.join(
                                cls.store.data['data']['config_data']['schedule_settings']['group_member']['cron_set'][
                                    'value'][
                                    'month'])
                            day = ','.join(
                                cls.store.data['data']['config_data']['schedule_settings']['group_member']['cron_set'][
                                    'value']['day'])
                            day_of_week_original = \
                                cls.store.data['data']['config_data']['schedule_settings']['group_member']['cron_set'][
                                    'value'][
                                    'day_of_week']
                            if day_of_week_original == ['*']:
                                day_of_week = ','.join(day_of_week_original)
                            elif isinstance(day_of_week_original, list):
                                day_of_week = ','.join([str(int(i) - 1) for i in day_of_week_original])
                            else:
                                day_of_week = ','.join(str(int(day_of_week_original) - 1))
                            hour = ','.join(
                                cls.store.data['data']['config_data']['schedule_settings']['group_member']['cron_set'][
                                    'value']['hour'])
                            minute = ','.join(
                                cls.store.data['data']['config_data']['schedule_settings']['group_member']['cron_set'][
                                    'value'][
                                    'minute'])
                            second = ','.join(
                                cls.store.data['data']['config_data']['schedule_settings']['group_member']['cron_set'][
                                    'value'][
                                    'second'])
                            value = {
                                'year': year, 'month': month, 'day': day, 'day_of_week': day_of_week, 'hour': hour,
                                'minute': minute, 'second': second
                            }
                            return_data = {
                                'trigger_type': AppType.cron,
                                'value': value
                            }
                        elif 'date_set' in store_data['data']['config_data']['schedule_settings']['group_member']:
                            value = store_data['data']['config_data']['schedule_settings']['group_member']['date_set'][
                                'value']
                            return_data = {
                                'trigger_type': AppType.date,
                                'value': value
                            }
        return return_data

    @classmethod
    def get_opc_r_group(cls):
        return cls.store.get_opc_r_group()

    @classmethod
    def get_opc_w_group(cls):
        return cls.store.get_opc_w_group()

    @classmethod
    def get_common_org_code(cls):
        return 'root'


##################################
# user api
##################################

def get_store():
    return Store.store


def get_logger():
    return Store.store.get_logger()


def set_store(new_store):
    data = new_store.get_data()
    app_uuid_file = Path(new_store.get_uuid_path())
    if app_uuid_file.is_file():
        with open(new_store.get_uuid_path(), 'r') as f:
            uuid_file = f.read()
            uuid_file = uuid_file.strip()
        if uuid_file:
            app_uuid = {
                'app_uuid': uuid_file
            }
            data.update(app_uuid)
        else:
            logger = new_store.get_logger()
            logger.error('lack uuid .appid is empty')
            raise LackUuidError
    else:
        logger = new_store.get_logger()
        logger.error('.appid file was not found')
        raise LackUuidError

    new_store_app_port = new_store.get_app_port()
    if new_store_app_port in block_ports:
        new_store.get_logger().error('app_port: ' + str(new_store_app_port) + ' is not allowed by Chrome')
        raise AppPortError
    Store.store = new_store
    organization_info = Store.store.organization_info()
    if organization_info:
        update_context('organization', organization_info)


def set_context(key, var):
    if key in Store.context:
        logger = get_logger()
        logger.error('set key to context failed, ' + str(key) + ' already exists')
        raise ValueError
    Store.context[key] = var


def get_context(key):
    if key in Store.context:
        return Store.context[key]
    else:
        return None


def update_context(key, var):
    Store.context[key] = var


def set_config_func(new_config_func):
    if iscoroutinefunction(new_config_func):
        update_context('config_func', new_config_func)
    else:
        logger = get_logger()
        logger.error('config_func is not a coroutine function. Coroutine functions are defined with async def.')
        raise FuncTypeError


def set_data_func(new_data_func):
    if iscoroutinefunction(new_data_func):
        update_context('data_func', new_data_func)
    else:
        logger = get_logger()
        logger.error('data_func is not a coroutine function. Coroutine functions are defined with async def.')
        raise FuncTypeError


def set_init_task(new_init_tasks_list):
    new_init_tasks = {}
    new_init_tasks_keys_list = [TaskKey.admin]
    logger = get_logger()
    if isinstance(new_init_tasks_list, list):
        for i in new_init_tasks_list:
            if isinstance(i, dict):
                if len(i) == 1:
                    i_keys = list(i.keys())
                    if i_keys[0] in TaskKey:
                        new_init_tasks.update(i)
                        new_init_tasks_keys_list.append(i_keys[0])
                    else:
                        logger.error('dict key wrong')
                        raise InitTaskError
                else:
                    logger.error('dict len wrong')
                    raise InitTaskError
            else:
                logger.error('init_task has element is not dict')
                raise InitTaskError
    else:
        logger.error('init_task is not a list')
        raise InitTaskError

    update_context('init_tasks_keys_list', new_init_tasks_keys_list)
    update_context('init_tasks', new_init_tasks)


def set_handler(key, var):
    get_context('handlers')[key] = var


def get_handler(key):
    return get_context('handlers')[key]


def get_uuid():
    try:
        data = Store.store.get_data()
        app_uuid = data['app_uuid']
    except Exception:
        app_uuid = None
    return app_uuid


def get_ha_role():
    try:
        ha_role = Store.store.data['data']['config_data']['ha_settings']['group_member']['ha_role']['value']
    except Exception:
        ha_role = None
    return ha_role


def get_organization():
    try:
        organization = get_context('organization')['code']
    except Exception:
        organization = None
    return organization


def get_organization_name():
    try:
        organization_name = get_context('organization')['name']
    except Exception:
        organization_name = None
    return organization_name


def get_organization_all():
    try:
        organization = get_context('organization_all')
    except Exception:
        organization = None
    return organization


def get_mongodb_cluster_info():
    """
    获取mongodb集群信息
    :return:
    mongo集群信息格式: {'host': '192.168.20.188,192.168.20.193,192.168.20.194', 'port': '27010'}
    """
    from mg_app_framework.util import log_exception
    mongodb_cluster_info = None
    try:
        mongodb_cluster_info = get_context('mongodb_cluster')
    except Exception as e:
        log_exception(e, '获取mongodb集群信息异常')
    return mongodb_cluster_info


def get_rabbitmq_info():
    """
    返回rabbitmq的相关信息
    :return:
    rabbitmq信息格式: {'host': '192.168.20.134', 'port': '5672', 'username': 'rabbitmq', 'password': '123456'}
    """
    from mg_app_framework.util import log_exception
    rabbitmq_info = None
    try:
        rabbitmq_info = get_context('rabbitmq')
    except Exception as e:
        log_exception(e, '获取rabbitmq信息异常')
    return rabbitmq_info
