import os, traceback
import tornado.ioloop
import tornado.web
import tornado.websocket
import json
from os.path import basename, dirname, join, exists

from mg_app_framework.config import Store, get_ha_role, get_logger, get_organization, update_context
from mg_app_framework.message import MesCode
from mg_app_framework.components import TaskKey
from mg_app_framework.client import HttpClient
from mg_app_framework.util import log_request
import urllib


class DataTypeError(Exception):
    pass


# 文件流(http下载模块用)
class FileStream:

    def __init__(self, filename):
        self.filename = filename

    def send(self, buf_size, http_handler):
        with open(self.filename, 'rb') as f:
            while True:
                data = f.read(buf_size)
                if not data:
                    break
                http_handler.write(data)


# 字节流(http下载模块用)
class BufferStream:

    def __init__(self, data):
        self.data = data

    def send(self, buf_size, http_handler):
        start_num = 0
        while True:
            data = self.data[start_num:start_num + buf_size]
            if not data:
                break
            http_handler.write(data)
            start_num += buf_size


class HttpBasicHandler(tornado.web.RequestHandler):

    def __init__(self, application, request, **kwargs):
        super(HttpBasicHandler, self).__init__(application, request, **kwargs)
        self.debug_name = 'admin'
        self.operator = None

    def set_default_headers(self):
        # 无论是否跨域，都预设如下response_header，在调试或者线上均可用
        self.set_header("Access-Control-Expose-Headers", "Content-Disposition")
        self.set_header("Access-Control-Allow-Origin", self.request.headers.get('Origin') or "*")
        self.set_header('Access-Control-Allow-Credentials', "true")

    @property
    def data(self):
        # 获取url 和 body中的参数
        argument_data = dict()
        a = self.request.query_arguments
        for i in a.keys():
            argument_data[i] = self.get_argument(i)
        if self.request.body:
            body_data = json.loads(self.request.body.decode('utf-8'))
            if isinstance(body_data, dict):
                body_data.update(argument_data)
                return body_data
            else:
                get_logger().exception('body data is not a dict')
                raise DataTypeError
        else:
            return argument_data

    @property
    async def login_name(self):
        if Store.context['debug_flag']:
            return Store.store.get_debug_login_name()
        try:
            login_name = self.get_cookie('login_name')
            if login_name:
                return login_name
            else:
                if self.request.body:
                    body_data = json.loads(self.request.body.decode('utf-8'))
                    if 'manugence_login_name' in body_data:
                        return body_data['manugence_login_name']
                if 'unionid' in self.request.headers:
                    union_id = self.request.headers['unionid']
                    login_url = Store.get_login_url()
                    client = HttpClient()
                    get_login_username_url = login_url + '/api/auth/user_name'
                    post_data = {'unionid': str(union_id)}
                    res = await client.post(get_login_username_url, data=post_data)
                    res_code = res.code
                    if res_code == MesCode.success:
                        res_data = res.data
                        login_name = res_data['user_name']
                    else:
                        get_logger().error('获取login_name失败')
            return login_name
        except Exception as e:
            get_logger().exception('get login_name fail: {}'.format(str(e)))
            traceback.print_exc()
            return None

    @property
    async def login_organization(self):
        try:
            organization = self.get_cookie('login_organization')
            if not organization:
                if self.request.body:
                    body_data = json.loads(self.request.body.decode('utf-8'))
                    if 'manugence_login_organization' in body_data:
                        return body_data['manugence_login_organization']
                if 'unionid' in self.request.headers:
                    union_id = self.request.headers['unionid']
                    login_url = Store.get_login_url()
                    client = HttpClient()
                    get_login_organization_url = login_url + '/api/auth/user_organization'
                    post_data = {'unionid': str(union_id)}
                    res = await client.post(get_login_organization_url, data=post_data)
                    res_code = res.code
                    if res_code == MesCode.success:
                        res_data = res.data
                        organization = res_data['user_organization']
                    else:
                        get_logger().error('获取login_organization失败')
            return organization
        except Exception as e:
            get_logger().exception('get login_organization fail: {}'.format(str(e)))
            traceback.print_exc()
            return None

    @property
    async def login_role(self):
        cookie_login_uuid = self.get_cookie('login_uuid')
        login_uuid = None
        union_id = None
        if cookie_login_uuid:
            login_uuid = cookie_login_uuid
        else:
            if self.request.body:
                body_data = json.loads(self.request.body.decode('utf-8'))
                if 'manugence_login_uuid' in body_data:
                    login_uuid = body_data['manugence_login_uuid']
            if 'unionid' in self.request.headers:
                union_id = self.request.headers['unionid']
        if login_uuid or union_id:
            login_url = Store.get_login_url()
            client = HttpClient()
            get_login_role_url = login_url + '/api/auth/user_role'

            if login_uuid:
                post_data = {'login_uuid': str(login_uuid)}
            else:
                post_data = {'unionid': str(union_id)}
            res = await client.post(get_login_role_url, data=post_data)
            res_code = res.code
            if res_code == MesCode.success:
                res_data = res.data
                user_role = res_data['user_role']
                # super_admin or role
                return user_role
            else:
                get_logger().error('get role fail')
        else:
            get_logger().error('获取login_role失败')

    def _set_response_data(self, result):
        try:
            self.finish(json.dumps(result, ensure_ascii=False))
        except Exception as e:
            self.finish(json.dumps(
                {"code": MesCode.fail, "info": str(e)}))
            traceback.print_exc()

    async def get_process(self, *args, **kwargs):
        pass

    async def post_process(self, *args, **kwargs):
        pass

    async def delete_process(self, *args, **kwargs):
        pass

    async def put_process(self, *args, **kwargs):
        pass

    async def _process(self, method_process, *args, **kwargs):
        result = dict()
        result['app_group'] = Store.get_app_group()
        result['app_name'] = Store.get_app_name()
        try:
            await method_process(*args, **kwargs)
        except Exception as e:
            traceback.print_exc()
            get_logger().error(str(e))
            result["code"] = MesCode.fail
            result["data"] = None
            result["info"] = str(e)
            self._set_response_data(result)

    def send_response_data(self, code, data=None, info=None):
        result = dict()
        result['app_group'] = Store.get_app_group()
        result['app_name'] = Store.get_app_name()
        if code == MesCode.success or code == MesCode.fail or code == MesCode.login:
            result["code"] = code
            result["data"] = data
            result["info"] = info
            self._set_response_data(result)
        else:
            get_logger().exception('HTTP return code is wrong')

    # http 下载接口
    def send_response_file(self, filename=None, data=None, buf_size=1024):
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename=%s; filename*=%s' %
                        (urllib.parse.quote(filename), urllib.parse.quote(filename)))
        try:
            data.send(buf_size, self)
        except Exception:
            traceback.print_exc()
            get_logger().exception('send_response_file data send wrong')
            get_logger().exception('data type = ' + str(type(data)))
        self.finish()

    @log_request
    async def get(self, *args, **kwargs):
        await self._process(self.get_process, *args, **kwargs)

    @log_request
    async def post(self, *args, **kwargs):
        await self._process(self.post_process, *args, **kwargs)

    @log_request
    async def put(self, *args, **kwargs):
        await self._process(self.put_process, *args, **kwargs)

    @log_request
    async def delete(self, *args, **kwargs):
        await self._process(self.delete_process, *args, **kwargs)


class HttpBasicCookieHandler(HttpBasicHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", self.request.headers.get("Origin") or "*")
        self.set_header('Access-Control-Allow-Credentials', "true")


class StaticFileBasicHandler(tornado.web.StaticFileHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", self.request.headers.get("Origin") or "*")
        self.set_header('Access-Control-Allow-Credentials', "true")

    def get_modified_time(self):
        return None


class SetCookieHandler(HttpBasicCookieHandler):

    async def post_process(self):
        try:
            req_data = self.data
            login_uuid = req_data['login_uuid']
            login_name = req_data['login_name']
            get_logger().info('set login cookie login_uuid == ' + str(login_uuid))
            get_logger().info('set login cookie login_name == ' + str(login_name))
            login_organization = None
            if 'login_organization' in req_data:
                login_organization = req_data['login_organization']
                if not login_organization:
                    # 单工厂模式从下发的配置中获取组织编码
                    login_organization = get_organization()
                get_logger().info('set login cookie login_organization == ' + str(login_organization))
            # cookie_path默认为根, 如果在云模式需要设置到组织编码路径下
            cookie_path = '/'
            if 'cookie_path' in req_data:
                cookie_path = '/{}'.format(req_data['cookie_path'])
            get_logger().info('cookie_path: {}'.format(cookie_path))
            if login_uuid and login_name:
                from urllib.parse import urlencode
                self.set_cookie('login_uuid', str(login_uuid), expires_days=1, domain=None, path=cookie_path)
                self.set_cookie('login_name', urlencode({'key': login_name}).split('=')[-1], expires_days=1, 
                                domain=None, path=cookie_path)
                if login_organization:
                    self.set_cookie('login_organization', str(login_organization), expires_days=1, domain=None,
                                    path=cookie_path)
                self.send_response_data(MesCode.success, None, 'cookie设置成功')
            else:
                self.send_response_data(MesCode.fail, None, 'cookie设置失败, 不能为None')
        except Exception as e:
            traceback.print_exc()
            get_logger().info(str(e))
            self.send_response_data(MesCode.fail, None, 'cookie设置失败')


class WebsocketBasicHandler(tornado.websocket.WebSocketHandler):
    def check_origin(self, origin):
        return True

    @property
    async def login_name(self):
        try:
            login_name = self.get_cookie('login_name')
            if login_name:
                return login_name
            else:
                return None
        except Exception as e:
            traceback.print_exc()
            get_logger().exception('get login_name fail')
            return None

    @property
    async def login_organization(self):
        try:
            login_organization = self.get_cookie('login_organization')
            if login_organization:
                return login_organization
            else:
                return None
        except Exception as e:
            traceback.print_exc()
            get_logger().exception('get login_organization fail')
            return None

    @property
    async def login_role(self):
        cookie_login_uuid = self.get_cookie('login_uuid')
        login_uuid = None
        if cookie_login_uuid:
            login_uuid = cookie_login_uuid
        if login_uuid:
            login_url = Store.get_login_url()
            client = HttpClient()
            get_login_role_url = login_url + '/api/auth/user_role'

            post_data = {
                'login_uuid': str(login_uuid)
            }
            res = await client.post(get_login_role_url, data=post_data)
            res_code = res.code
            if res_code == MesCode.success:
                res_data = res.data
                user_role = res_data['user_role']
                # super_admin or role
                return user_role
            else:
                get_logger().error('get role fail')
        else:
            get_logger().error('cookie login_uuid is None')


class AppLogoFetchHandler(HttpBasicHandler):
    async def get_process(self):
        from mg_app_framework.util import log_exception

        logo_data = None
        try:
            # logo数据格式为: {org_code: logo_base64}
            # 对于业务app直接获取manager下发的组织信息
            organization = get_organization()
            if not organization:
                # 对于公共组件从cookie项login_organization获取
                organization = self.get_cookie('login_organization')

            if not organization:
                get_logger().info('获取图片失败, 获取组织信息失败')
                self.send_response_data(MesCode.fail, None, '获取图片失败, 获取组织信息失败')
                return

            app_data = Store.store.get_data()
            if app_data and 'app_logo' in app_data and organization in app_data['app_logo']:
                logo_data = app_data['app_logo'][organization]
            if logo_data:
                self.send_response_data(MesCode.success, logo_data, None)
                get_logger().info('从manager获取logo数据成功')
            else:
                self.send_response_data(MesCode.fail, None, None)
                get_logger().info('从manager获取logo数据失败')
        except Exception as e:
            traceback.print_exc()
            self.send_response_data(MesCode.fail, None, None)
            log_exception(e, '获取app logo数据异常')


def _get_urls_file(path, apps_url, module_url):
    try:
        for filename in os.listdir(path):
            full_path = os.path.join(path, filename)
            if os.path.isdir(full_path):
                _get_urls_file(full_path, apps_url, module_url)
            elif filename == 'urls.py':
                apps_url += getattr(
                    __import__((module_url + os.path.join(path.split(module_url)[1], 'urls')).replace(os.sep, '.'),
                               fromlist=['url']), 'url')
    except Exception as e:
        traceback.print_exc()
        get_logger().exception(e)


def _get_app_urls():
    app_urls = []
    module_dir = Store.get_module_dir()
    handlers_dir = join(module_dir, 'handlers')
    if exists(handlers_dir):
        module_name = basename(module_dir)
        _get_urls_file(handlers_dir, app_urls, os.path.join(module_name, 'handlers'))
        if len(app_urls) > 0:
            # 给每个app额外添加2个默认的接口, 一个是设置登录相关cookie, 另一个是从manager获取logo
            app_urls += [
                (r'/api/auth/set_cookie', SetCookieHandler),
                (r'/api/config/get_app_logo', AppLogoFetchHandler)
            ]

    app_urls = _check_ha_url(app_urls)
    app_urls = _check_sds_url(app_urls)

    format_app_urls = []  # tornado 不解析url里增加的中文
    func_name_url_note_map = {}  # func_name 和 url_note映射
    for url in app_urls:
        format_app_urls.append((url[0], url[1]))
        if len(url) > 2:  # url里有中文,
            # DO: 此处原本使用key=func_name;修改为key=url
            func_name_url_note_map[url[0]] = url[2]

    update_context('func_name_url_note_map', func_name_url_note_map)
    return format_app_urls


def _check_ha_url(url):
    from mg_app_framework.components.ha import HaWebHandler
    init_keys = Store.get_init_task_keys()
    if TaskKey.ha in init_keys and get_ha_role() is not None:
        url += [
            (r'/ha_connect_url', HaWebHandler),
        ]
    return url


def _check_sds_url(url):
    from mg_app_framework.components.sds import is_sds_enabled, get_app_online_url, get_app_msg_url
    # Enabled SDS
    if is_sds_enabled():
        url += get_app_online_url()
        url += get_app_msg_url()

    return url


def make_process_app():
    app_urls = _get_app_urls()
    if len(app_urls) > 0:
        app = tornado.web.Application(app_urls)
        app.listen(Store.get_app_port(), address=Store.get_app_ip())


def make_user_app():
    from tornado_swagger.setup import setup_swagger
    static_dir = join(dirname(dirname(Store.get_module_dir())), 'static', 'dist')

    app_urls = _get_app_urls()
    static_route = (r'/(.*)', StaticFileBasicHandler, {'path': static_dir, 'default_filename': "index.html"})
    final_routes = []
    final_routes.extend(app_urls)
    final_routes.extend([static_route])
    if Store.store.get_swagger_enable():
        swagger_routes = [tornado.web.url(url[0], url[1], url[2] if len(url) > 2 else None) for url in final_routes]
        app_data = Store.store.get_data()
        organization = '' if Store.context['debug_flag'] else get_organization()
        setup_swagger(
            swagger_routes,
            api_base_url=f"/{organization}",
            swagger_url=f"{app_data.get('app_module_name', '')}/docs",
            description=f"{app_data.get('app_name', '')}API文档",
            api_version=app_data.get('app_version', '1.0.0'),
            title=app_data.get('app_name', '')
        )
        app = tornado.web.Application(swagger_routes, websocket_ping_interval=30)
    else:
        app = tornado.web.Application(final_routes, websocket_ping_interval=30)
    app.listen(Store.get_app_port(), address=Store.get_app_ip())
