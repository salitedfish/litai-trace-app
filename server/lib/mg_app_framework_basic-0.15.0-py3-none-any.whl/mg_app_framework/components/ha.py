from mg_app_framework.config import Store, AppHaRole, get_ha_role, get_handler, update_context, get_context, \
    get_logger
from tornado import websocket, gen
import json
from tornado.ioloop import IOLoop
from mg_app_framework.message import HaMesType, send_mes_sync, make_mes, MesCode, MesType
from inspect import iscoroutinefunction
from mg_app_framework.scheduler import update_scheduler
from abc import ABCMeta, abstractmethod
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task


class HaConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


except_sleep_time = 1


class HaFuncBasic(metaclass=ABCMeta):
    @abstractmethod
    async def ha_message_func(self, mes):
        pass

    @abstractmethod
    def ha_close_func(self, mes):
        pass

    def retry_interval(self):
        return 5


# 构造ha消息
def make_ha_message(ha_follower_uuid=None, ha_role=None, ha_close=None):
    ha_message = dict()
    if ha_follower_uuid:
        ha_message['ha_follower_uuid'] = ha_follower_uuid
    elif ha_role:
        ha_message['ha_role'] = ha_role
        ha_message['config_data'] = Store.store.get_data()
    elif ha_close:
        ha_message['ha_close'] = True
    return ha_message


# ha监听逻辑入口
async def run_ha_receive_func(ha_receive_cycle_func, message_dict):
    if ha_receive_cycle_func is not None:
        get_logger().info('run ha func. message == ' + str(message_dict))
        if iscoroutinefunction(ha_receive_cycle_func):
            result = await ha_receive_cycle_func(message_dict)
        else:
            result = ha_receive_cycle_func(message_dict)
        return result
    else:
        return MesCode.success


# ha websocket连接服务接口
def get_ha_url():
    return [
        (r'/ha_connect_url', HaWebHandler),
    ]


class HaWebHandler(websocket.WebSocketHandler):
    def check_origin(self, origin):
        return True

    async def open(self):
        update_context('ha_connection', self)
        get_logger().info('ha connection')

    async def on_message(self, message):
        message_dict = json.loads(message)
        store = Store.get_init_task_config(TaskKey.ha)
        # 初始化ha连接消息
        if message_dict['type'] == HaMesType.init_connect:
            ha_message = make_ha_message(ha_follower_uuid=message_dict['data']['app_uuid'])
            Store.store.get_data()['ha_follower_uuid'] = message_dict['data']['app_uuid']
            # master app接收到 follower 初始化连接消息后，发送消息给manager，
            # manager将master app的配置加上 follower app的uuid，这样页面展示的时候可以感知到master 配对的app是哪个
            send_mes_sync(get_handler(TaskKey.admin), MesType.ha, ha_message)
            if message_dict['info'] == AppHaRole.master and get_ha_role() == AppHaRole.follower:
                # 如果对面是master， 自己当前是follower， 则将对方的配置更新到自己
                await ha_auto_update_data(message_dict)
                # 更新标识对面角色 的内存变量
                update_context('ha_other_side_role', AppHaRole.master)

            else:
                update_context('ha_other_side_role', AppHaRole.follower)
            ha_receive_cycle_func = store.ha_message_func
            await run_ha_receive_func(ha_receive_cycle_func, message_dict)

            # 将自己的配置信息发给对方
            self.write_message(
                json.dumps(make_mes(HaMesType.init_connect, Store.store.get_data(), get_ha_role())))

        # 如果是更新配置消息，则进行自身配置更新逻辑
        elif message_dict['type'] == HaMesType.ha_auto_update:
            await ha_auto_update_data(message_dict)

        # 接收到切换角色信息 逻辑分支
        elif message_dict['type'] == HaMesType.change_to_follower or message_dict['type'] == HaMesType.change_to_master:
            ha_receive_cycle_func = store.ha_message_func
            result = await run_ha_receive_func(ha_receive_cycle_func, message_dict)
            if result == MesCode.success:
                # 运行app自身定义逻辑成功，重置定时器以及改变角色
                reset_scheduler()
                change_role(message_dict)
            elif result == MesCode.fail:
                get_logger().info('update ' + str(message_dict['type']) + ' fail')
        else:
            ha_receive_cycle_func = store.ha_message_func
            await run_ha_receive_func(ha_receive_cycle_func, message_dict)
            reset_scheduler()

    def on_close(self):
        # 感受到断开连接时，发送告警
        send_mes_sync(get_handler(TaskKey.admin), MesType.alarm, info='ha 主备连接断开')
        update_context('ha_connection', None)
        update_context('ha_other_side_role', None)
        ha_close_message = make_ha_message(ha_close=True)
        Store.store.get_data()['ha_follower_uuid'] = None
        send_mes_sync(get_handler(TaskKey.admin), MesType.ha, ha_close_message)
        close_message = make_mes(HaMesType.connection_close)
        store = Store.get_init_task_config(TaskKey.ha)
        ha_close_func = store.ha_close_func
        # 运行app 自定义的ha关闭逻辑
        if ha_close_func is not None:
            ha_close_func(close_message)
        ha_role = get_ha_role()
        # 如果此时是follower角色，改变为master角色
        if ha_role == AppHaRole.follower:
            Store.set_ha_role(AppHaRole.master)
            ha_role_message = make_ha_message(ha_role=AppHaRole.master)
            send_mes_sync(get_handler(TaskKey.admin), MesType.alarm, info='ha 角色切换为 master')
            send_mes_sync(get_handler(TaskKey.admin), MesType.ha, ha_role_message)
        get_logger().info('ha connection closed')


# 创建ha连接
async def start_ha_connect(conn_time=None):
    if get_ha_role() == AppHaRole.follower:
        await ha_connect(conn_time=conn_time)
    start_next_task(TaskKey.ha)


# 备连主
async def ha_connect(re_conn=False, conn_time=None):
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Ha connect error,connect more than ' + str(conn_time) + ' times')
                raise HaConnectError
            websocket_url = Store.get_ha_websocket_url()
            if websocket_url is not None:
                # ha ping 3秒超时
                ha_handler = await websocket.websocket_connect(websocket_url, ping_interval=1, ping_timeout=3)
                get_logger().info('ha connected successfully')
                Store.set_ha_handler(ha_handler)
                send_mes_sync(ha_handler, HaMesType.init_connect, Store.store.get_data(), get_ha_role())
                if not re_conn:
                    loop = Store.get_loop()
                    loop.spawn_callback(ha_process)
                break
        except Exception:
            __cnt += 1
            get_logger().exception('ha connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.ha)
            await gen.sleep(store.retry_interval())


# ha 监听协程启动入口
async def ha_process():
    while True:
        try:
            ha_handler = Store.get_ha_handler()
            if ha_handler is not None:
                await ha_receive_cycle()
                break
            else:
                get_logger().info("wait ha websocket connect ")
                await gen.sleep(except_sleep_time)
        except Exception as e:
            get_logger().exception("ha websocket receive_cycle error:%s" % str(e))
            await gen.sleep(except_sleep_time)


# 角色切换
def change_role(msg):
    # master --> follower
    if msg['type'] == HaMesType.change_to_follower and get_ha_role() != AppHaRole.follower:
        get_logger().info('change_to_follower')
        Store.set_ha_role(AppHaRole.follower)
        update_context('ha_other_side_role', AppHaRole.master)
        ha_role_message = make_ha_message(ha_role=AppHaRole.follower)
        send_mes_sync(get_handler(TaskKey.admin), MesType.alarm, info='ha 角色切换为 follower')
        send_mes_sync(get_handler(TaskKey.admin), MesType.ha, ha_role_message)

    # follower --> master
    elif msg['type'] == HaMesType.change_to_master and get_ha_role() != AppHaRole.master:
        get_logger().info('change_to_master')
        Store.set_ha_role(AppHaRole.master)
        update_context('ha_other_side_role', AppHaRole.follower)
        ha_role_message = make_ha_message(ha_role=AppHaRole.master)
        send_mes_sync(get_handler(TaskKey.admin), MesType.alarm, info='ha 角色切换为 master')
        send_mes_sync(get_handler(TaskKey.admin), MesType.ha, ha_role_message)


# 重置定时器
def reset_scheduler():
    scheduler = get_context('scheduler')
    if scheduler:
        if Store.get_switch():
            scheduler.resume()
        else:
            scheduler.pause()
        update_scheduler()


# ha 自动更新data配置
async def ha_auto_update_data(msg_dict):
    get_logger().info('ha_auto_update_data before updating: ' + str(Store.get_data()))
    auto_update_data = dict()
    if isinstance(msg_dict['data'], dict):
        new_data = msg_dict['data']
    else:
        new_data = json.loads(msg_dict['data'])

    if 'switch' in new_data:
        auto_update_data['switch'] = new_data['switch']
    temp_data = new_data['data']

    auto_update_data['data'] = temp_data
    old_data = Store.store.get_data()
    old_ha_settings = None
    # ha的配置部分不更新
    if 'ha_settings' in old_data['data']['key_list']:
        if 'ha_settings' in old_data['data']['config_data']:
            old_ha_settings = old_data['data']['config_data']['ha_settings']
    if old_ha_settings is not None:
        auto_update_data['data']['config_data']['ha_settings'].update(old_ha_settings)
    Store.store.get_data()['data'].update(auto_update_data['data'])
    if 'switch' in auto_update_data:
        Store.set_switch(auto_update_data['switch'])

    reset_scheduler()
    config_func = Store.get_config_func()
    await config_func()
    get_logger().info('ha_auto_update_data after updating: ' + str(Store.get_data()))
    send_mes_sync(get_handler(TaskKey.admin), MesType.update_config, Store.get_data())


# ha监听逻辑(客户端)
async def ha_receive_cycle():
    ioloop = IOLoop.current()

    async def cycle():
        while True:
            try:
                ha_handler = Store.get_ha_handler()
                if ha_handler is not None:
                    msg = await ha_handler.read_message()
                    if msg:
                        msg_dict = json.loads(msg)
                        # 初始化ha连接消息
                        if msg_dict['type'] == HaMesType.init_connect:
                            store = Store.get_init_task_config(TaskKey.ha)
                            update_context('ha_other_side_role', msg_dict['info'])

                            # 如果对面是master  则更新自身配置
                            if msg_dict['info'] == AppHaRole.master:
                                await ha_auto_update_data(msg_dict)
                                # 如果对面是master  且 自己目前也是master， 则将自己改变为follower
                                if get_ha_role() == AppHaRole.master:
                                    change_to_follower_message_dict = make_mes(HaMesType.change_to_follower)
                                    ha_receive_cycle_func = store.ha_message_func
                                    result = await run_ha_receive_func(ha_receive_cycle_func,
                                                                       change_to_follower_message_dict)
                                    if result == MesCode.success:
                                        change_role(change_to_follower_message_dict)
                                    elif result == MesCode.fail:
                                        get_logger().info('client app role change master to follow fail')

                            ha_receive_cycle_func = store.ha_message_func
                            await run_ha_receive_func(ha_receive_cycle_func, msg_dict)
                        # 如果是更新配置消息，则进行自身配置更新逻辑
                        elif msg_dict['type'] == HaMesType.ha_auto_update:
                            await ha_auto_update_data(msg_dict)

                        # 接收到切换角色信息 逻辑分支
                        elif msg_dict['type'] == HaMesType.change_to_master or msg_dict['type'] == \
                                HaMesType.change_to_follower:
                            store = Store.get_init_task_config(TaskKey.ha)
                            ha_receive_cycle_func = store.ha_message_func
                            result = await run_ha_receive_func(ha_receive_cycle_func, msg_dict)
                            if result == MesCode.success:
                                reset_scheduler()
                                change_role(msg_dict)
                            elif result == MesCode.fail:
                                get_logger().info('update ' + str(msg_dict['type']) + ' fail')
                        else:
                            store = Store.get_init_task_config(TaskKey.ha)
                            ha_receive_cycle_func = store.ha_message_func
                            await run_ha_receive_func(ha_receive_cycle_func, msg_dict)
                            reset_scheduler()
                    else:
                        # 感受到主备连接断开情况，逻辑分支
                        get_logger().info('ha connect close')
                        Store.set_ha_handler(None)
                        update_context('ha_other_side_role', None)
                        send_mes_sync(get_handler(TaskKey.admin), MesType.alarm, info='ha 主备连接断开')
                        close_message = make_mes(HaMesType.connection_close)
                        store = Store.get_init_task_config(TaskKey.ha)
                        ha_close_func = store.ha_close_func
                        if ha_close_func is not None:
                            ha_close_func(close_message)
                        ha_role = get_ha_role()
                        # 如果此时是follower角色，改变为master角色
                        if ha_role == AppHaRole.follower:
                            Store.set_ha_role(AppHaRole.master)
                            ha_role_message = make_ha_message(ha_role=AppHaRole.master)
                            send_mes_sync(get_handler(TaskKey.admin), MesType.alarm, info='ha 角色切换为 master')
                            send_mes_sync(get_handler(TaskKey.admin), MesType.ha, ha_role_message)
                else:
                    # 重连
                    await ha_connect(True)
                    await gen.sleep(except_sleep_time)
            except Exception as e:
                await gen.sleep(except_sleep_time)
                get_logger().exception('ha_receive_cycle error: %s' % str(e))

    ioloop.spawn_callback(cycle)
